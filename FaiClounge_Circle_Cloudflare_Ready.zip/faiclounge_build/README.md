# FaiClounge Circle — Cloudflare-ready community website

This package contains the redesigned public website plus a real member system and private administrator dashboard.

## Updated contact details
- Email: **faiccloungecircle@gmail.com**
- Facebook: https://www.facebook.com/profile.php?id=61595001060739
- Instagram: https://www.instagram.com/servalvisuals?stkn=MXN5bzI1azk4Y3g0Yw==
- WhatsApp: **0772855254** (international link: +263 772 855 254)
- Calls: **0772855254**
- SMS: **0772855254**

## What is included
- Responsive FaiClounge Circle landing page matching the supplied design.
- Public articles and testimonials.
- Membership registration and member login.
- Strong password requirements: 12+ characters, uppercase, lowercase, number and symbol.
- Passwords are PBKDF2-hashed; plaintext passwords are never stored.
- Honeypot + timing checks for basic bot protection; optional Cloudflare Turnstile support.
- Member profiles with bio and profile-photo upload.
- Member article publishing with optional image attachments.
- Article likes, comments and share button.
- Private admin dashboard at `/admin.html`.
- Admin member list, moderation, article/testimonial management, notifications and site settings.
- Email notification on a new membership registration when Resend is configured.
- Cloudflare D1 database for members/content.
- Cloudflare R2 bucket for profile/article images.

## Important: this is not a purely static website
The member accounts, passwords, dashboard, uploads and email notifications require Cloudflare **Pages Functions + D1 + R2**. Do not treat this as an ordinary HTML-only upload.

## Cloudflare setup
1. Create a Cloudflare Pages project.
2. Create a D1 database named `faiclounge-circle-db`.
3. Create an R2 bucket named `faiclounge-circle-media`.
4. Put the real D1 `database_id` into `wrangler.toml` where it says `REPLACE_WITH_YOUR_D1_DATABASE_ID`.
5. Apply the database schema from `schema.sql` to the D1 database. With Wrangler:
   `npx wrangler d1 execute faiclounge-circle-db --remote --file=schema.sql`
6. Deploy the project with Wrangler/Pages so the `functions/` directory is deployed. A typical command is:
   `npx wrangler pages deploy . --project-name faiclounge-circle`
7. In Cloudflare Pages → Settings → Environment variables, configure:
   - `ADMIN_EMAIL` = `faiccloungecircle@gmail.com`
   - `SITE_URL` = your real site URL
   - `ADMIN_SETUP_KEY` = a long random secret used only for first-time admin setup
   - `RESEND_API_KEY` = your Resend API key (for email notifications)
   - `MAIL_FROM` = a verified sender, for example `FaiClounge Circle <notifications@yourdomain.com>`
   - `TURNSTILE_SITE_KEY` = optional public Turnstile site key
   - `TURNSTILE_SECRET_KEY` = optional Turnstile secret key
8. Ensure the D1 binding is named `DB` and the R2 binding is named `MEDIA`, matching `wrangler.toml`.
9. Open `/admin-setup.html` once, enter the `ADMIN_SETUP_KEY`, and create your strong admin password.
10. Remove/unset `ADMIN_SETUP_KEY` after the admin account has been created.
11. Use `/admin.html` for the private dashboard.

## Email notifications
The application sends a notification email to `ADMIN_EMAIL` after a successful member registration. The email is sent through Resend when `RESEND_API_KEY` is configured. For reliable production delivery, verify your sending domain in Resend and use the verified address in `MAIL_FROM`.

## Social profiles
The Facebook and Instagram buttons have been updated to the exact links supplied. Other social links should be replaced with your real profile URLs when you have them.

## Security notes
- Never put API keys or admin passwords into HTML/JavaScript.
- Keep all secrets in Cloudflare environment variables/secrets.
- Enable Turnstile for stronger anti-bot protection in production.
- Use HTTPS (Cloudflare provides this for the deployed site).
- Review and moderate member-generated content from the admin dashboard.

## Files
`index.html` public home, `join.html` membership, `member.html` member portal, `admin.html` dashboard, `admin-setup.html` first-time setup, `article.html` public article page, `functions/` backend API, `schema.sql` database schema, `wrangler.toml` Cloudflare bindings, `assets/` site images.
