import {json,readJson,hashPassword,passwordValid,randomToken,cookie,verifyTurnstile} from '../../_utils.js';
export async function onRequestPost({request,env}){
 const d=await readJson(request); if(!d)return json({error:'Invalid request'},400);
 if(d.website)return json({error:'Registration rejected'},400);
 if(Date.now()-Number(d.startedAt||0)<2500)return json({error:'Please complete the form normally.'},429);
 if(!(await verifyTurnstile(request,env,d.turnstileToken)))return json({error:'Security check failed.'},400);
 const fullName=String(d.fullName||'').trim(),email=String(d.email||'').trim().toLowerCase(),phone=String(d.phone||'').trim(),location=String(d.location||'').trim(),address=String(d.address||'').trim(),password=String(d.password||''),confirm=String(d.confirmPassword||'');
 if(fullName.length<3||email.length<5||phone.length<7||location.length<2||address.length<3)return json({error:'Please complete all required fields.'},400);
 if(password!==confirm)return json({error:'Passwords do not match.'},400); if(!passwordValid(password))return json({error:'Password must be at least 12 characters and include uppercase, lowercase, number and symbol.'},400);
 const existing=await env.DB.prepare('SELECT id FROM members WHERE email=?').bind(email).first(); if(existing)return json({error:'An account with that email already exists.'},409);
 const ph=await hashPassword(password); const res=await env.DB.prepare('INSERT INTO members(full_name,email,phone,location,address,password_hash) VALUES(?,?,?,?,?,?)').bind(fullName,email,phone,location,address,ph).run();
 const memberId=res.meta.last_row_id; await env.DB.prepare('INSERT INTO notifications(type,subject,body) VALUES(?,?,?)').bind('membership','New membership registration',`${fullName} registered with ${email}. Phone: ${phone}. Location: ${location}.`).run();
 if(env.ADMIN_EMAIL) await (await import('../../_utils.js')).sendEmail(env,env.ADMIN_EMAIL,'New FaiClounge Circle membership',`${fullName} registered as a new member.\nEmail: ${email}\nPhone: ${phone}\nLocation: ${location}\nAddress: ${address}`);
 const sid=randomToken(32); await env.DB.prepare('INSERT INTO sessions(id,member_id,expires_at) VALUES(?,?,?)').bind(sid,memberId,Math.floor(Date.now()/1000)+60*60*24*30).run();
 return json({ok:true,message:'Account created successfully.'},201,{ 'Set-Cookie': cookie('fc_session',sid,{maxAge:60*60*24*30})});
}
